from datetime import date

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

from .models import (
    Student,
    Faculty,
    Subject,
    Attendance,
    UserProfile
)


def login_page(request):

    if request.user.is_authenticated:

        if request.user.is_superuser:
            return redirect("/admin/")

        try:
            profile = UserProfile.objects.get(
                user=request.user
            )

            if profile.role == "faculty":
                return redirect("/dashboard/")

            if profile.role == "student":
                return redirect("/student-dashboard/")

        except UserProfile.DoesNotExist:
            pass

    if request.method == "POST":

        username = request.POST.get("username")
        password = request.POST.get("password")
        selected_role = request.POST.get("role")

        user = authenticate(
            request,
            username=username,
            password=password
        )

        if user is not None:

            if user.is_superuser:

                if selected_role != "admin":

                    return render(
                        request,
                        "login.html",
                        {
                            "error":
                            "Please select Admin for this account."
                        }
                    )

                login(request, user)

                return redirect("/admin/")

            try:

                profile = UserProfile.objects.get(
                    user=user
                )

            except UserProfile.DoesNotExist:

                return render(
                    request,
                    "login.html",
                    {
                        "error":
                        "No role is assigned to this account."
                    }
                )

            if profile.role != selected_role:

                return render(
                    request,
                    "login.html",
                    {
                        "error":
                        "Selected role does not match this account."
                    }
                )

            login(request, user)

            if profile.role == "faculty":
                return redirect("/dashboard/")

            if profile.role == "student":
                return redirect("/student-dashboard/")

        else:

            return render(
                request,
                "login.html",
                {
                    "error":
                    "Invalid username or password."
                }
            )

    return render(
        request,
        "login.html"
    )


@login_required
def dashboard(request):

    if request.user.is_superuser:
        return redirect("/admin/")

    try:

        profile = UserProfile.objects.get(
            user=request.user
        )

    except UserProfile.DoesNotExist:

        return redirect("/")

    if profile.role != "faculty":
        return redirect("/")

    try:

        faculty = Faculty.objects.get(
            email=request.user.email
        )

    except Faculty.DoesNotExist:

        return render(
            request,
            "dashboard.html",
            {
                "error":
                "No faculty record is linked to this account."
            }
        )

    subjects = Subject.objects.filter(
        faculty=faculty
    )

    subjects_count = subjects.count()

    attendance_records = Attendance.objects.filter(
        subject__in=subjects
    )

    total_records = attendance_records.count()

    present_records = attendance_records.filter(
        status=True
    ).count()

    if total_records > 0:

        attendance_percentage = round(
            (present_records / total_records) * 100,
            2
        )

    else:

        attendance_percentage = 0

    students_count = Student.objects.count()

    today = date.today()

    today_records = attendance_records.filter(
        date=today
    )

    today_total = today_records.count()

    today_present = today_records.filter(
        status=True
    ).count()

    today_absent = today_records.filter(
        status=False
    ).count()

    if today_total > 0:

        today_percentage = round(
            (today_present / today_total) * 100,
            2
        )

    else:

        today_percentage = 0

    return render(
        request,
        "dashboard.html",
        {
            "faculty": faculty,
            "subjects": subjects,
            "subjects_count": subjects_count,
            "students_count": students_count,
            "attendance_percentage": attendance_percentage,
            "today_total": today_total,
            "today_present": today_present,
            "today_absent": today_absent,
            "today_percentage": today_percentage,
            "today": today
        }
    )


def logout_user(request):

    logout(request)

    return redirect("/")


@login_required
def mark_attendance(request):

    if request.user.is_superuser:
        return redirect("/admin/")

    try:

        profile = UserProfile.objects.get(
            user=request.user
        )

    except UserProfile.DoesNotExist:

        return redirect("/")

    if profile.role != "faculty":
        return redirect("/")

    try:

        faculty = Faculty.objects.get(
            email=request.user.email
        )

    except Faculty.DoesNotExist:

        return render(
            request,
            "mark_attendance.html",
            {
                "error":
                "No faculty record is linked to this account."
            }
        )

    subjects = Subject.objects.filter(
        faculty=faculty
    )

    students = Student.objects.all().order_by(
        "roll_number"
    )

    if request.method == "POST":

        subject_id = request.POST.get("subject")

        selected_date = request.POST.get("date")

        if not subject_id:

            return render(
                request,
                "mark_attendance.html",
                {
                    "subjects": subjects,
                    "students": students,
                    "error":
                    "Please select a subject."
                }
            )

        if not selected_date:

            return render(
                request,
                "mark_attendance.html",
                {
                    "subjects": subjects,
                    "students": students,
                    "error":
                    "Please select a date."
                }
            )

        try:

            subject = Subject.objects.get(
                id=subject_id
            )

        except Subject.DoesNotExist:

            return render(
                request,
                "mark_attendance.html",
                {
                    "subjects": subjects,
                    "students": students,
                    "error":
                    "Selected subject does not exist."
                }
            )

        if subject.faculty != faculty:

            return render(
                request,
                "mark_attendance.html",
                {
                    "subjects": subjects,
                    "students": students,
                    "error":
                    "You are not authorized to mark attendance for this subject."
                }
            )

        try:

            attendance_date = date.fromisoformat(
                selected_date
            )

        except ValueError:

            return render(
                request,
                "mark_attendance.html",
                {
                    "subjects": subjects,
                    "students": students,
                    "error":
                    "Please enter a valid date."
                }
            )

        if attendance_date > date.today():

            return render(
                request,
                "mark_attendance.html",
                {
                    "subjects": subjects,
                    "students": students,
                    "error":
                    "Attendance cannot be marked for a future date."
                }
            )

        for student in students:

            status = request.POST.get(
                f"status_{student.id}"
            )

            if status in [
                "present",
                "absent"
            ]:

                Attendance.objects.update_or_create(

                    student=student,

                    subject=subject,

                    date=attendance_date,

                    defaults={
                        "status":
                        status == "present"
                    }
                )

        return redirect(
            "/dashboard/"
        )

    return render(
        request,
        "mark_attendance.html",
        {
            "students": students,
            "subjects": subjects
        }
    )



@login_required
def attendance_history(request):

    if request.user.is_superuser:
        return redirect("/admin/")

    # Check user role
    try:

        profile = UserProfile.objects.get(
            user=request.user
        )

    except UserProfile.DoesNotExist:

        return redirect("/")

    if profile.role != "faculty":

        return redirect("/")

    # Find faculty
    try:

        faculty = Faculty.objects.get(
            email=request.user.email
        )

    except Faculty.DoesNotExist:

        return redirect("/")

    # Only show subjects assigned to this faculty
    subjects = Subject.objects.filter(
        faculty=faculty
    )

    # Get attendance records
    attendance_records = Attendance.objects.filter(
        subject__in=subjects
    ).select_related(
        "student",
        "subject"
    ).order_by(
        "-date",
        "student__roll_number"
    )

    # Get filters
    selected_subject = request.GET.get(
        "subject"
    )

    selected_date = request.GET.get(
        "date"
    )

    search_query = request.GET.get(
        "search"
    )

    # Subject filter
    if selected_subject:

        attendance_records = attendance_records.filter(
            subject_id=selected_subject
        )

    # Date filter
    if selected_date:

        attendance_records = attendance_records.filter(
            date=selected_date
        )

    # Student search
    if search_query:

        attendance_records = attendance_records.filter(

            student__roll_number__icontains=
            search_query

        ) | attendance_records.filter(

            student__name__icontains=
            search_query
        )

    return render(
        request,
        "attendance_history.html",
        {
            "attendance_records":
            attendance_records,

            "subjects":
            subjects,

            "selected_subject":
            selected_subject,

            "selected_date":
            selected_date,

            "search_query":
            search_query
        }
    )

@login_required
def low_attendance(request):

    if request.user.is_superuser:
        return redirect("/admin/")

    # Check user role
    try:

        profile = UserProfile.objects.get(
            user=request.user
        )

    except UserProfile.DoesNotExist:

        return redirect("/")

    if profile.role != "faculty":

        return redirect("/")

    # Find faculty
    try:

        faculty = Faculty.objects.get(
            email=request.user.email
        )

    except Faculty.DoesNotExist:

        return redirect("/")

    # Get only subjects assigned to this faculty
    subjects = Subject.objects.filter(
        faculty=faculty
    )

    students = Student.objects.all().order_by(
        "roll_number"
    )

    threshold = 75

    low_attendance_records = []

    # Check every student
    for student in students:

        # Check every subject of this faculty
        for subject in subjects:

            records = Attendance.objects.filter(
                student=student,
                subject=subject
            )

            total = records.count()

            present = records.filter(
                status=True
            ).count()

            # Ignore subjects where attendance
            # has not been recorded
            if total == 0:

                continue

            percentage = round(
                (present / total) * 100,
                2
            )

            # Add only attendance below 75%
            if percentage < threshold:

                low_attendance_records.append(
                    {
                        "student": student,

                        "subject": subject,

                        "total": total,

                        "present": present,

                        "percentage": percentage
                    }
                )

    return render(
        request,
        "low_attendance.html",
        {
            "low_attendance_records":
            low_attendance_records,

            "threshold":
            threshold
        }
    )

@login_required
def edit_attendance(
    request,
    attendance_id
):

    if request.user.is_superuser:
        return redirect("/admin/")

    try:

        profile = UserProfile.objects.get(
            user=request.user
        )

    except UserProfile.DoesNotExist:

        return redirect("/")

    if profile.role != "faculty":
        return redirect("/")

    try:

        faculty = Faculty.objects.get(
            email=request.user.email
        )

    except Faculty.DoesNotExist:

        return redirect("/")

    try:

        attendance = Attendance.objects.select_related(
            "student",
            "subject"
        ).get(
            id=attendance_id
        )

    except Attendance.DoesNotExist:

        return redirect(
            "/attendance-history/"
        )

    if attendance.subject.faculty != faculty:

        return redirect(
            "/attendance-history/"
        )

    if request.method == "POST":

        status = request.POST.get(
            "status"
        )

        if status == "present":

            attendance.status = True

        elif status == "absent":

            attendance.status = False

        attendance.save()

        return redirect(
            "/attendance-history/"
        )

    return render(
        request,
        "edit_attendance.html",
        {
            "attendance":
            attendance
        }
    )


@login_required
def student_dashboard(request):

    if request.user.is_superuser:
        return redirect("/admin/")

    try:

        profile = UserProfile.objects.get(
            user=request.user
        )

    except UserProfile.DoesNotExist:

        return redirect("/")

    if profile.role != "student":
        return redirect("/")

    try:

        student = Student.objects.get(
            email=request.user.email
        )

    except Student.DoesNotExist:

        return render(
            request,
            "student_dashboard.html",
            {
                "error":
                "No student record is linked to this account."
            }
        )

    attendance_records = Attendance.objects.filter(
        student=student
    ).select_related(
        "subject"
    ).order_by(
        "-date"
    )

    total_classes = attendance_records.count()

    present_classes = attendance_records.filter(
        status=True
    ).count()

    if total_classes > 0:

        overall_percentage = round(
            (
                present_classes /
                total_classes
            ) * 100,
            2
        )

    else:

        overall_percentage = 0

    threshold = 75

    is_low_attendance = (
        total_classes > 0
        and
        overall_percentage < threshold
    )

    subjects = Subject.objects.all()

    subject_attendance = []

    for subject in subjects:

        records = attendance_records.filter(
            subject=subject
        )

        total = records.count()

        present = records.filter(
            status=True
        ).count()

        if total > 0:

            percentage = round(
                (
                    present /
                    total
                ) * 100,
                2
            )

            subject_attendance.append(
                {
                    "subject": subject,
                    "total": total,
                    "present": present,
                    "percentage": percentage
                }
            )

    return render(
        request,
        "student_dashboard.html",
        {
            "student": student,
            "overall_percentage": overall_percentage,
            "total_classes": total_classes,
            "present_classes": present_classes,
            "subject_attendance": subject_attendance,
            "attendance_records": attendance_records,
            "threshold": threshold,
            "is_low_attendance": is_low_attendance
        }
    )