from django.contrib import admin

from .models import (
    Student,
    Faculty,
    Subject,
    Attendance,
    UserProfile
)


admin.site.register(Student)

admin.site.register(Faculty)

admin.site.register(Subject)

admin.site.register(Attendance)

admin.site.register(UserProfile)