from django.urls import path

from .views import (
    login_page,
    dashboard,
    logout_user,
    mark_attendance,
    attendance_history,
    low_attendance,
    edit_attendance,
    student_dashboard
)


urlpatterns = [

    path(
        "",
        login_page,
        name="login"
    ),

    path(
        "dashboard/",
        dashboard,
        name="dashboard"
    ),

    path(
        "student-dashboard/",
        student_dashboard,
        name="student_dashboard"
    ),

    path(
        "logout/",
        logout_user,
        name="logout"
    ),

    path(
        "mark-attendance/",
        mark_attendance,
        name="mark_attendance"
    ),

    path(
        "attendance-history/",
        attendance_history,
        name="attendance_history"
    ),

    path(
        "low-attendance/",
        low_attendance,
        name="low_attendance"
    ),

    path(
        "edit-attendance/<int:attendance_id>/",
        edit_attendance,
        name="edit_attendance"
    ),

]