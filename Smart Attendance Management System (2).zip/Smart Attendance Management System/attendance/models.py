from django.db import models
from django.contrib.auth.models import User


class Student(models.Model):

    roll_number = models.CharField(
        max_length=20,
        unique=True
    )

    name = models.CharField(
        max_length=100
    )

    email = models.EmailField(
        unique=True
    )

    department = models.CharField(
        max_length=100
    )

    section = models.CharField(
        max_length=20
    )

    def __str__(self):

        return f"{self.roll_number} - {self.name}"


class Faculty(models.Model):

    name = models.CharField(
        max_length=100
    )

    email = models.EmailField(
        unique=True
    )

    department = models.CharField(
        max_length=100
    )

    def __str__(self):

        return self.name


class Subject(models.Model):

    name = models.CharField(
        max_length=100
    )

    code = models.CharField(
        max_length=20,
        unique=True
    )

    faculty = models.ForeignKey(
        Faculty,
        on_delete=models.CASCADE
    )

    def __str__(self):

        return f"{self.code} - {self.name}"


class Attendance(models.Model):

    student = models.ForeignKey(
        Student,
        on_delete=models.CASCADE
    )

    subject = models.ForeignKey(
        Subject,
        on_delete=models.CASCADE
    )

    date = models.DateField()

    status = models.BooleanField(
        default=False
    )

    class Meta:

        constraints = [
            models.UniqueConstraint(
                fields=[
                    "student",
                    "subject",
                    "date"
                ],
                name="unique_student_subject_date"
            )
        ]

    def __str__(self):

        status = "Present" if self.status else "Absent"

        return (
            f"{self.student.name} - "
            f"{self.subject.name} - "
            f"{status}"
        )


class UserProfile(models.Model):

    ROLE_CHOICES = [
        ("admin", "Admin"),
        ("faculty", "Faculty"),
        ("student", "Student"),
    ]

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE
    )

    role = models.CharField(
        max_length=20,
        choices=ROLE_CHOICES
    )

    def __str__(self):

        return f"{self.user.username} - {self.role}"